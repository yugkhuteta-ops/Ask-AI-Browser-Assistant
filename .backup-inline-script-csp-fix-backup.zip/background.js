/**
 * background.js — Service worker for Ask AI extension
 *
 * Multi-AI routing logic:
 * - Reads ai_provider from chrome.storage.sync (default: "chatgpt")
 * - Routes selected text to the correct AI platform
 * - For Gemini: uses ?prompt= URL parameter (no content script needed)
 * - For others: stores pendingPrompt and uses autosend content scripts
 */

const AI_CONFIG = {
  chatgpt: {
    name: "ChatGPT",
    url: "https://chatgpt.com/",
    urlPattern: "https://chatgpt.com/*"
  },

  gemini: {
    name: "Gemini",
    url: "https://gemini.google.com/app",
    urlPattern: "https://gemini.google.com/*",
    usesUrlParam: true  // Gemini supports ?prompt= for auto-fill
  },
  perplexity: {
    name: "Perplexity",
    url: "https://www.perplexity.ai/",
    urlPattern: "https://www.perplexity.ai/*"
  }
};

/**
 * Create or update the context menu based on the selected provider.
 */
function updateContextMenu(provider) {
  const config = AI_CONFIG[provider] || AI_CONFIG.chatgpt;
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "ask-ai",
      title: `Ask ${config.name}: "%s"`,
      contexts: ["selection"]
    });
  });
}

// On install/update: set up context menu with saved provider
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get({ ai_provider: "chatgpt" }, ({ ai_provider }) => {
    updateContextMenu(ai_provider);
  });
});

// Update context menu when provider changes in options page
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.ai_provider) {
    updateContextMenu(changes.ai_provider.newValue);
  }
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "ask-ai" && info.selectionText) {
    sendToAI(info.selectionText.trim());
  }
});

// Handle messages from popup-bar.js
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "ASK_AI" && msg.text) {
    sendToAI(msg.text.trim());
  }
});

/**
 * Main routing function.
 * Reads the selected AI provider and routes the text accordingly.
 */
function sendToAI(text) {
  chrome.storage.sync.get({ ai_provider: "chatgpt" }, ({ ai_provider }) => {
    const config = AI_CONFIG[ai_provider] || AI_CONFIG.chatgpt;

    if (config.usesUrlParam) {
      // Gemini: use URL parameter — no pendingPrompt or content script needed
      sendViaUrlParam(config, text);
    } else {
      // ChatGPT, Claude, Perplexity: use pendingPrompt + autosend content script
      sendViaPendingPrompt(config, text);
    }
  });
}

/**
 * Route via URL parameter (Gemini).
 * Opens or reuses a Gemini tab with ?prompt=text appended.
 */
function sendViaUrlParam(config, text) {
  const targetUrl = `${config.url}?prompt=${encodeURIComponent(text)}`;

  chrome.tabs.query({ url: config.urlPattern }, (tabs) => {
    if (tabs.length > 0) {
      // Reuse existing tab — navigate it to the prompt URL
      const target = tabs.sort(
        (a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)
      )[0];
      chrome.tabs.update(target.id, { active: true, url: targetUrl });
      chrome.windows.update(target.windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: targetUrl });
    }
  });
}

/**
 * Route via pendingPrompt storage + autosend content script.
 * Used for ChatGPT, Claude, and Perplexity.
 */
function sendViaPendingPrompt(config, text) {
  chrome.storage.local.set({ pendingPrompt: text }, () => {
    chrome.tabs.query({ url: config.urlPattern }, (tabs) => {
      if (tabs.length > 0) {
        // Pick the most recently accessed tab
        const target = tabs.sort(
          (a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)
        )[0];

        chrome.tabs.update(target.id, { active: true });
        chrome.windows.update(target.windowId, { focused: true });

        // Inject trigger event into the existing tab.
        // MV3 service workers can sleep and page readiness is racy,
        // so we retry a few times and log failures.
        // Note: We must dispatch from the page context; some pages/frames
        // may need a focus to ensure content scripts have run.
        try {
          // Ensure tab is active before dispatching.
          chrome.tabs.update(target.id, { active: true });
          chrome.windows.update(target.windowId, { focused: true });
        } catch (e) {
          // ignore
        }

        const dispatchEvent = () =>
          chrome.scripting.executeScript({
            target: { tabId: target.id },
            func: () => {
              window.dispatchEvent(new CustomEvent("ai-autosend"));
            }
          });

        try {
          dispatchEvent();
          if (chrome.runtime.lastError) {
            console.warn("[Ask AI] executeScript lastError:", chrome.runtime.lastError);
          }
        } catch (err) {
          console.warn("[Ask AI] dispatchEvent failed:", err);
        }

        // Retry dispatch shortly to cover cases where the content script listener
        // wasn't attached yet when the first dispatch happened.
        setTimeout(() => {
          try {
            dispatchEvent();
            if (chrome.runtime.lastError) {
              console.warn("[Ask AI] executeScript retry lastError:", chrome.runtime.lastError);
            }
          } catch (err) {
            console.warn("[Ask AI] dispatchEvent retry failed:", err);
          }
        }, 750);

        setTimeout(() => {
          try {
            dispatchEvent();
            if (chrome.runtime.lastError) {
              console.warn("[Ask AI] executeScript retry2 lastError:", chrome.runtime.lastError);
            }
          } catch (err) {
            console.warn("[Ask AI] dispatchEvent retry2 failed:", err);
          }
        }, 1600);
      } else {
        chrome.tabs.create({ url: config.url });
      }
    });
  });
}